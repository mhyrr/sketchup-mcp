require 'sketchup.rb'

module SU_MCP
  class Server
    def initialize(port = 9876)
      @port = port
      @server = nil
      @running = false
      @components = {}
    end

    def start
      return if @running
      
      @server = TCPServer.new('localhost', @port)
      @running = true
      
      UI.messagebox("MCP Server started on port #{@port}")
      
      # Start server in a separate thread
      @thread = Thread.new { run_server }
    end

    def stop
      return unless @running
      
      @running = false
      @server.close if @server
      @thread.kill if @thread
      
      UI.messagebox("MCP Server stopped")
    end

    private

    def run_server
      while @running
        begin
          client = @server.accept
          handle_client(client)
        rescue => e
          puts "Error: #{e.message}"
        end
      end
    end

    def handle_client(client)
      Thread.new do
        begin
          while line = client.gets
            command = JSON.parse(line)
            response = handle_command(command)
            client.puts(JSON.generate(response))
          end
        rescue => e
          puts "Client error: #{e.message}"
        ensure
          client.close
        end
      end
    end

    def handle_command(command)
      case command['command']
      when 'create_component'
        create_component(command['parameters'])
      when 'delete_component'
        delete_component(command['parameters'])
      when 'transform'
        transform_component(command['parameters'])
      when 'get_selection'
        get_selection(command['parameters'])
      when 'set_material'
        set_material(command['parameters'])
      when 'export'
        export_scene(command['parameters'])
      else
        { success: false, error: "Unknown command: #{command['command']}" }
      end
    end

    def create_component(params)
      model = Sketchup.active_model
      entities = model.active_entities
      
      begin
        model.start_operation('Create Component', true)
        
        case params['type'].downcase
        when 'cube'
          point = params['position'] || [0,0,0]
          size = params['dimensions'] || [1,1,1]
          
          # Create the cube
          group = entities.add_group
          face = group.entities.add_face([
            point,
            [point[0] + size[0], point[1], point[2]],
            [point[0] + size[0], point[1] + size[1], point[2]],
            [point[0], point[1] + size[1], point[2]]
          ])
          face.pushpull(size[2])
          
          component_id = group.entityID
          @components[component_id] = group
          
          model.commit_operation
          
          { success: true, result: { id: component_id } }
        else
          model.abort_operation
          { success: false, error: "Unsupported component type: #{params['type']}" }
        end
      rescue => e
        model.abort_operation
        { success: false, error: e.message }
      end
    end

    def delete_component(params)
      model = Sketchup.active_model
      component_id = params['id']
      
      begin
        component = @components[component_id]
        return { success: false, error: 'Component not found' } unless component
        
        model.start_operation('Delete Component', true)
        component.erase!
        @components.delete(component_id)
        model.commit_operation
        
        { success: true }
      rescue => e
        model.abort_operation
        { success: false, error: e.message }
      end
    end

    def transform_component(params)
      model = Sketchup.active_model
      component_id = params['id']
      
      begin
        component = @components[component_id]
        return { success: false, error: 'Component not found' } unless component
        
        model.start_operation('Transform Component', true)
        
        # Handle position
        if params['position']
          translation = Geom::Vector3d.new(
            params['position'][0] - component.bounds.center.x,
            params['position'][1] - component.bounds.center.y,
            params['position'][2] - component.bounds.center.z
          )
          component.transform!(Geom::Transformation.translation(translation))
        end
        
        # Handle rotation
        if params['rotation']
          rotation = Geom::Transformation.rotation(
            component.bounds.center,
            Z_AXIS, params['rotation'][2].degrees
          )
          component.transform!(rotation)
        end
        
        # Handle scale
        if params['scale']
          scale = Geom::Transformation.scaling(
            component.bounds.center,
            params['scale'][0],
            params['scale'][1],
            params['scale'][2]
          )
          component.transform!(scale)
        end
        
        model.commit_operation
        { success: true }
      rescue => e
        model.abort_operation
        { success: false, error: e.message }
      end
    end

    def get_selection(params)
      model = Sketchup.active_model
      selection = model.selection
      
      selected_ids = selection.map { |entity| 
        id = entity.entityID
        @components[id] = entity if entity.is_a?(Sketchup::Group)
        id
      }
      
      { success: true, result: { selected_ids: selected_ids } }
    end

    def set_material(params)
      model = Sketchup.active_model
      component_id = params['id']
      material_name = params['material']
      
      begin
        component = @components[component_id]
        return { success: false, error: 'Component not found' } unless component
        
        model.start_operation('Set Material', true)
        
        # Find or create material
        material = model.materials[material_name] || model.materials.add(material_name)
        
        # Apply material
        component.material = material
        
        model.commit_operation
        { success: true }
      rescue => e
        model.abort_operation
        { success: false, error: e.message }
      end
    end

    def export_scene(params)
      model = Sketchup.active_model
      format = params['format'] || 'skp'
      
      begin
        # Get temporary file path
        temp_path = File.join(Dir.tmpdir, "export.#{format}")
        
        case format.downcase
        when 'skp'
          model.save(temp_path)
        else
          return { success: false, error: "Unsupported export format: #{format}" }
        end
        
        { success: true, result: { path: temp_path } }
      rescue => e
        { success: false, error: e.message }
      end
    end
  end

  # Create menu commands
  unless file_loaded?(__FILE__)
    @server = Server.new
    
    UI.menu('Extensions').add_item('Start MCP Server') {
      @server.start
    }
    
    UI.menu('Extensions').add_item('Stop MCP Server') {
      @server.stop
    }
    
    file_loaded(__FILE__)
  end
end 