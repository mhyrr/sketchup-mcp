# Sketchup MCP

A Model Context Protocol (MCP) server for Sketchup that allows AI agents to control and manipulate scenes through the desktop app's Ruby API.

## Features

- TCP-based communication with Sketchup
- Support for basic geometry operations (create, delete, transform)
- Material management
- Scene export
- Selection handling

## Installation

1. Create a ZIP file with this structure:
```
su_mcp.rbz
├── su_mcp.rb
└── su_mcp/
    ├── main.rb
    └── LICENSE
```

2. Rename the ZIP file to `su_mcp.rbz`

3. In Sketchup:
   - Window > Extension Manager
   - Click "Install Extension" button
   - Select the `su_mcp.rbz` file
   - Restart Sketchup if prompted

The extension adds two menu items under Extensions:
- "Start MCP Server" - Starts TCP server on port 9876
- "Stop MCP Server" - Stops the server

## Usage

1. Start the MCP server from Sketchup's Extensions menu

2. Send MCP commands using Python. Example:

```python
import mcp

client = mcp.Client()

# Create a cube
response = client.execute({
    "command": "create_component",
    "parameters": {
        "type": "cube",
        "position": [0, 0, 0],
        "dimensions": [10, 10, 10]
    }
})

# Get the component ID from the response
component_id = response["result"]["id"]

# Move it
client.execute({
    "command": "transform",
    "parameters": {
        "id": component_id,
        "position": [20, 0, 0],
        "rotation": [0, 0, 45]
    }
})
```

## Supported Commands

- `create_component`: Create new geometry
  - Currently supports: cube
  - Parameters: type, position, dimensions

- `delete_component`: Remove a component
  - Parameters: id

- `transform`: Move, rotate, or scale a component
  - Parameters: id, position (optional), rotation (optional), scale (optional)

- `get_selection`: Get currently selected components
  - Returns: list of component IDs

- `set_material`: Apply materials to components
  - Parameters: id, material (name)

- `export`: Export the scene
  - Parameters: format (default: 'skp')
  - Returns: path to exported file

## Development

The extension uses Sketchup's Ruby API to:
- Create and manage geometry
- Handle transformations
- Manage materials
- Export scenes

All operations are wrapped in transactions for undo/redo support. 