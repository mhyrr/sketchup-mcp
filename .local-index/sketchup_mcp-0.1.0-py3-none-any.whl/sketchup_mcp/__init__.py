"""Sketchup integration through Model Context Protocol"""

from .server import mcp  # This exports the FastMCP instance for Claude to use 